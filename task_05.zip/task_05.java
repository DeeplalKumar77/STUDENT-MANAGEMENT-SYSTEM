import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentManagementSystem sms = new StudentManagementSystem();

    public static void main(String[] args) {
        while (true) {
            printMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    addStudentUI();
                    break;
                case "2":
                    editStudentUI();
                    break;
                case "3":
                    searchStudentUI();
                    break;
                case "4":
                    displayAllStudentsUI();
                    break;
                case "5":
                    removeStudentUI();
                    break;
                case "6":
                    System.out.println("Exiting application. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n--- Student Management System ---");
        System.out.println("1. Add New Student");
        System.out.println("2. Edit Existing Student");
        System.out.println("3. Search for a Student");
        System.out.println("4. Display All Students");
        System.out.println("5. Remove a Student");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addStudentUI() {
        System.out.println("\n--- Add New Student ---");
        String rollNumber = inputRollNumber();
        if (sms.searchStudent(rollNumber) != null) {
            System.out.println("Student with this roll number already exists.");
            return;
        }
        String name = inputName();
        String grade = inputGrade();
        String email = inputEmail();

        Student student = new Student(name, rollNumber, grade, email);
        if (sms.addStudent(student)) {
            System.out.println("Student added successfully.");
        } else {
            System.out.println("Failed to add student.");
        }
    }

    private static void editStudentUI() {
        System.out.println("\n--- Edit Existing Student ---");
        String rollNumber = inputRollNumber();
        Student existingStudent = sms.searchStudent(rollNumber);
        if (existingStudent == null) {
            System.out.println("Student not found.");
            return;
        }
        System.out.println("Current details: " + existingStudent);

        String name = inputName();
        String grade = inputGrade();
        String email = inputEmail();

        Student updatedStudent = new Student(name, rollNumber, grade, email);
        if (sms.updateStudent(rollNumber, updatedStudent)) {
            System.out.println("Student updated successfully.");
        } else {
            System.out.println("Failed to update student.");
        }
    }

    private static void searchStudentUI() {
        System.out.println("\n--- Search for a Student ---");
        String rollNumber = inputRollNumber();
        Student student = sms.searchStudent(rollNumber);
        if (student != null) {
            System.out.println("Student found: " + student);
        } else {
            System.out.println("Student not found.");
        }
    }

    private static void displayAllStudentsUI() {
        System.out.println("\n--- All Students ---");
        List<Student> students = sms.getAllStudents();
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            students.forEach(System.out::println);
        }
    }

    private static void removeStudentUI() {
        System.out.println("\n--- Remove a Student ---");
        String rollNumber = inputRollNumber();
        if (sms.removeStudent(rollNumber)) {
            System.out.println("Student removed successfully.");
        } else {
            System.out.println("Student not found.");
        }
    }

    // Input validation methods

    private static String inputRollNumber() {
        while (true) {
            System.out.print("Enter Roll Number (non-empty): ");
            String rollNumber = scanner.nextLine().trim();
            if (!rollNumber.isEmpty()) {
                return rollNumber;
            }
            System.out.println("Roll Number cannot be empty.");
        }
    }

    private static String inputName() {
        while (true) {
            System.out.print("Enter Name (non-empty): ");
            String name = scanner.nextLine().trim();
            if (!name.isEmpty()) {
                return name;
            }
            System.out.println("Name cannot be empty.");
        }
    }

    private static String inputGrade() {
        while (true) {
            System.out.print("Enter Grade (A, B, C, D, F): ");
            String grade = scanner.nextLine().trim().toUpperCase();
            if (grade.matches("[ABCDF]")) {
                return grade;
            }
            System.out.println("Invalid grade. Please enter one of A, B, C, D, F.");
        }
    }

    private static String inputEmail() {
        while (true) {
            System.out.print("Enter Email (optional, press Enter to skip): ");
            String email = scanner.nextLine().trim();
            if (email.isEmpty()) {
                return "";
            }
            if (isValidEmail(email)) {
                return email;
            }
            System.out.println("Invalid email format.");
        }
    }

    private static boolean isValidEmail(String email) {
        String emailRegex = "^[\\w-\\.]+@[\\w-]+\\.[a-z]{2,4}$";
        return Pattern.compile(emailRegex, Pattern.CASE_INSENSITIVE).matcher(email).matches();
    }
}